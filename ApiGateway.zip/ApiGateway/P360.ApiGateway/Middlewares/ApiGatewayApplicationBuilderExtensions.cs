namespace P360.ApiGateway.Middlewares;

public static class ApiGatewayApplicationBuilderExtensions
{
    public static WebApplication UseApiGatewayMiddlewares(this WebApplication app)
    {
        if (app.Environment.IsDevelopment() || app.Configuration.GetValue<bool>("Swagger:Enabled"))
        {
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "P360 API Gateway");
                options.SwaggerEndpoint("/project/swagger/v1/swagger.json", "Project Service");
                options.SwaggerEndpoint("/user-account/swagger/v1/swagger.json", "User Account Service");
                options.RoutePrefix = "swagger";
            });
        }

        app.MapGet("/gateway/health", () => Results.Ok(new { status = "Healthy", service = "ApiGateway" }))
            .WithName("GatewayHealth")
            .WithTags("Gateway");

        app.MapGet("/gateway/swagger/downstream", () => Results.Ok(new[]
            {
                new
                {
                    service = "Project",
                    gatewaySwaggerUrl = "/project/swagger/v1/swagger.json",
                    serviceBaseUrl = "http://localhost:5254",
                    healthUrl = "/project/health"
                },
                new
                {
                    service = "UserAccount",
                    gatewaySwaggerUrl = "/user-account/swagger/v1/swagger.json",
                    serviceBaseUrl = "http://localhost:5018",
                    healthUrl = "/user-account/health"
                }
            }))
            .WithName("GatewayDownstreamSwagger")
            .WithTags("Gateway");

        app.MapReverseProxy();

        return app;
    }
}
