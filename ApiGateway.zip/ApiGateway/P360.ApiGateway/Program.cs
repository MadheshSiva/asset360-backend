using P360.ApiGateway.IoC;
using P360.ApiGateway.Middlewares;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddApiGatewayServices(builder.Configuration);

var app = builder.Build();
app.UseApiGatewayMiddlewares();
await app.RunAsync();
